package com.maxmazaitovv.pdfmaker

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    class Im(val w: Int, val h: Int, val d: ByteArray)

    private lateinit var web: WebView
    private val L = java.util.Collections.synchronizedList(ArrayList<Im>())
    private var pending: ByteArray? = null

    private fun js(s: String) = runOnUiThread { web.evaluateJavascript(s, null) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0b1020")
        window.navigationBarColor = Color.parseColor("#0b1020")
        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(Color.parseColor("#0b1020"))
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun load(u: Uri) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 2400) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        var bm: Bitmap = contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw Exception("rasm ochilmadi")
        val rot = try {
            contentResolver.openInputStream(u)!!.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            }
        } catch (e: Exception) { 0f }
        if (rot != 0f) bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(rot) }, true)
        val out = Bitmap.createBitmap(bm.width, bm.height, Bitmap.Config.ARGB_8888)
        Canvas(out).apply { drawColor(Color.WHITE); drawBitmap(bm, 0f, 0f, null) }
        val bo = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 85, bo)
        L.add(Im(out.width, out.height, bo.toByteArray()))
        val k = 240f / maxOf(out.width, out.height)
        val th = Bitmap.createScaledBitmap(out, maxOf(1, (out.width * k).toInt()), maxOf(1, (out.height * k).toInt()), true)
        val to = ByteArrayOutputStream()
        th.compress(Bitmap.CompressFormat.JPEG, 70, to)
        js("addThumb('data:image/jpeg;base64," + Base64.encodeToString(to.toByteArray(), Base64.NO_WRAP) + "')")
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rs != RESULT_OK || d == null) { if (rq == 1) js("st('')"); return }
        if (rq == 1) {
            val us = ArrayList<Uri>()
            val c = d.clipData
            if (c != null) { for (i in 0 until c.itemCount) us.add(c.getItemAt(i).uri) } else { d.data?.let { us.add(it) } }
            js("st('Yuklanmoqda…')")
            Thread {
                var ok = 0
                for (u in us) {
                    try { load(u); ok++ } catch (e: Throwable) {
                        js("st('Xatolik: " + (e.message ?: "").replace("'", " ") + "')")
                    }
                }
                if (ok > 0) js("st('" + ok + " ta rasm tayyor ✅')")
            }.start()
        }
        val u = d.data
        if (rq == 2 && u != null) {
            try {
                contentResolver.openOutputStream(u)?.use { it.write(pending) }
                Toast.makeText(this, "PDF saqlandi ✅", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Xatolik: " + e.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun pick() {
            runOnUiThread {
                try {
                    startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("image/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true), 1)
                } catch (e: Exception) { js("st('Galereya ochilmadi')") }
            }
        }
        @JavascriptInterface
        fun img(i: Int): String {
            val m = L[i]
            return m.w.toString() + "," + m.h + "," + Base64.encodeToString(m.d, Base64.NO_WRAP)
        }
        @JavascriptInterface
        fun del(i: Int) { if (i in 0 until L.size) L.removeAt(i) }
        @JavascriptInterface
        fun swap(i: Int) { if (i in 1 until L.size) { val t = L[i]; L[i] = L[i - 1]; L[i - 1] = t } }
        @JavascriptInterface
        fun save(b64: String, name: String) {
            pending = Base64.decode(b64, Base64.DEFAULT)
            runOnUiThread {
                startActivityForResult(
                    Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("application/pdf").putExtra(Intent.EXTRA_TITLE, name), 2)
            }
        }
    }
}
