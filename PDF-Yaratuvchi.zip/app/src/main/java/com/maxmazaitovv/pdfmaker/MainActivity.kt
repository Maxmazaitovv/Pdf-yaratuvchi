package com.maxmazaitovv.pdfmaker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var cb: ValueCallback<Array<Uri>>? = null
    private var pending: ByteArray? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0b1020")
        window.navigationBarColor = Color.parseColor("#0b1020")
        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(Color.parseColor("#0b1020"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null)
                cb = c
                return try { startActivityForResult(p.createIntent(), 1); true } catch (e: Exception) { cb = null; false }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 1) {
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d))
            cb = null
        }
        val u = d?.data
        if (rq == 2 && rs == RESULT_OK && u != null) {
            try {
                contentResolver.openOutputStream(u)?.use { it.write(pending) }
                Toast.makeText(this, "PDF saqlandi ✅", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Xatolik: " + e.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun save(b64: String, name: String) {
            pending = Base64.decode(b64, Base64.DEFAULT)
            runOnUiThread {
                startActivityForResult(
                    Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("application/pdf").putExtra(Intent.EXTRA_TITLE, name), 2)
            }
        }
    }
}
